<?php include('db_connect.php');

$username = $_POST['username'];
$password = $_POST['password'];
$userlevel = $_POST['userlevel'];

if(isset('submit')){
	
}
?>