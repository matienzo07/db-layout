<!-- Latest compiled and minified JavaScript -->
<script>

    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });

	$(document).ready(function(){
  		$('[data-toggle="tooltip"]').tooltip();
	});

	//Button on click with toggle
	
</script>
<!-- Menu Toggle Script -->
</body>
</html>