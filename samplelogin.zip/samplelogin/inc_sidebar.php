

<div class="border-right shadow mb-4 bg-white "id="sidebar-wrapper">
        <div id="side-color" class="sidebar-heading p-5 ">
            <img src="image/icon1.png" alt="image" class="rounded-circle mx-auto d-block" style="width:60px;height:60px;">
              <h6 class="text-white text-center">Administrator<br><small>Admin</small></h6>      
        </div>
           
              <!-- List Group Collapse-->
        <div class="list-group list-group-flush">

              <!-- Production List-->
            <a href="select.php" class="list-group-item list-group-item-action list-group-item-light  
              text-dark">
              <i class="fa fa-plus" id="icon"></i><b> Employee Table</b>
            <i class="fa fa-angle-left float-right" id="icon"></i>
            </a> 

                    <!--Inventory List-->
          <a href="login.php" class="list-group-item list-group-item-action list-group-item-light text-dark"  
              data-toggle="collapse" data-target="#pageSubmenu2">
              <i class="fa fa-tags" id="icon"></i> 
                <b>Login</b>
                <i class="fa fa-angle-left float-right" id="icon"></i>
          </a>

          <!--<ul class="collapse list-group" id="pageSubmenu2">   
              <a class="nav-link text-darknav-link" href="./inventory/invent.php"> 
                <i class="fa fa-edit" id="icon"></i> 
                  PO Receiving
              </a>
              <a class="nav-link" href="./inventory/purchase-receipt.php">
                <i class="fa fa-file" id="icon"></i>  
                  Purchase Receipt
              </a> 
              <a class="nav-link" href="./inventory/transfer-request.php">
                <i class="fa fa-copy" id="icon"></i> 
                  Transfer Request
              </a>
              <a class="nav-link" href="./inventory/transfer-order.php">
                <i class="fa fa-paste" id="icon"></i>  
                  Tranfer Order</a>
              <a class="nav-link" href="./inventory/transfer-shipment.php">
                <i class="fa fa-truck" id="icon"></i>  
                  Tranfer Shipment</a>
              <a class="nav-link" href="./inventory/transfer-receipt.php">
                <i class="fa fa-exchange" id="icon"></i> 
                  Tranfer Receipt
              </a>
              <a class="nav-link" href="./inventory/traceability.php">
                <i class="fa fa-search" id="icon"></i> 
                  Traceability
              </a>
              <a class="nav-link" href="./inventory/barcode-printing.php">
                <i class="fa fa-barcode" id="icon"></i>  
                  Barcode Printing
              </a>
          </ul>-->
                  <!--End Inventory List-->

          <!--Master List
          <a href="#index" class="list-group-item list-group-item-action list-group-item-light text-dark"  
              data-toggle="collapse" data-target="#pageSubmenu3">
              <i class="fa fa-tasks" id="icon"></i>
                <b>Master Files</b>
                <i class="fa fa-angle-left float-right" id="icon"></i>
          </a> 

          <ul class="collapse list-group" id="pageSubmenu3">   
              <a class="nav-link" href="./masterfiles/item-master.php">
                <i class="fa fa-qrcode" id="icon"></i> 
                  Item Master
              </a>
              <a class="nav-link" href="./masterfiles/bill-off-material.php">
                <i class="fa fa-list-alt" id="icon"></i>
                  Bill of Matrial
              </a>
          </ul>
                  <!--End Master List-->

          <!--Appication Setup
          <a href="#index" class="list-group-item list-group-item-action list-group-item-light text-dark"  
              data-toggle="collapse" data-target="#pageSubmenu4">
              <i class="fa fa-cogs" id="icon"></i>
                <b>Application Setup</b>
                <i class="fa fa-angle-left float-right" id="icon"></i>
          </a>

          <ul class="collapse list-group" id="pageSubmenu4">   
              <a class="nav-link " href="./application/order-forecast-matrix.php">
                <i class="fa fa-list-ol" id="icon"></i>
                  Order Forecast Matrix
              </a>
              <a class="nav-link" href="./application/item-group.php">
                <i class="fa fa-chain" id="icon"></i> 
                  Item Group
              </a> 
              <a class="nav-link" href="./application/transfer-cost-setup.php">
                <i class="fa fa-truck" id="icon"></i>
                  Transfer Cost Setup
              </a>
              <a class="nav-link" href="./application/production-cost-setup.php">
                <i class="fa fa-exchange" id="icon"></i>
                  Production Cost Setup
              </a>
              <a class="nav-link" href="./application/sub-location.php">
                <i class="fa fa-map-marker" id="icon"></i>
                  Sub Location Setup
              </a>
          </ul>

          <a href="#index" class="list-group-item list-group-item-action list-group-item-light text-dark"  
              data-toggle="collapse" data-target="#pageSubmenu5">
                <i class="fa fa-tasks" id="icon"></i>
                  <b>Reports</b>
                  <i class="fa fa-angle-left float-right" id="icon"></i>
          </a>        
          <ul class="collapse list-group" id="pageSubmenu5">   
              <a class="nav-link" href="./reports/inventory-movement.php">
                <i class="fa fa-file-pdf-o" id="icon"></i>
                  Inventory Movement
              </a>
              <a class="nav-link" href="./reports/production-report.php">
                <i class="fa fa-file-pdf-o" id="icon"></i>
                  Production Report
              </a> 
              <a class="nav-link" href="./reports/receiving-report.php">
                <i class="fa fa-file-pdf-o" id="icon"></i>
                  Receivng Report</a>
              <a class="nav-link" href="./reports/inventory-report.php">
                <i class="fa fa-file-pdf-o" id="icon"></i>
                  Inventory Report
              </a>
          </ul>

          <a href="document.php" class="list-group-item list-group-item-action list-group-item-light text-dark">
            <i class="fa fa-envelope" id="icon"></i>
              <b>Document Approval</b>
          </a>  -->      
                  
      </div>
        <!--End Appication Setup-->
    </div>
    <!-- /#sidebar-wrapper -->